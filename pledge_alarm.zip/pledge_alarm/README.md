# 押金闹钟（Pledge Alarm）— 合法演示版

> **这是什么**：一个"赖床终结者"闹钟。你先押一笔**虚拟**押金，设好闹钟时间与宽限时间；响铃后必须在宽限内点「我起床了」才能**原数退还**押金，超时未确认则押金被「没收」并记入本地账本（去向可选：公益捐出 / 自己认栽）。贪睡能续命，但每次扣罚金。
>
> **重要边界**：本 App **不接入任何真实支付**，押金是本地虚拟数值，赖床「没收」只写进手机本地账本，**钱不会流向开发者，也不会真的从任何人钱包扣款**。要做成真实扣款产品，需要接入支付网关 + 资金存管 + 合规，那已超出「本地打包」范畴。

## 功能

- 首页：设虚拟押金金额、闹钟时间、确认宽限（1–30 分钟）、贪睡时长与罚金、没收去向
- 响铃页：全屏 + 循环报警音 + 屏幕常亮（锁屏也能弹），强制确认起床；倒计时归零自动没收
- 贪睡：每次续命 N 分钟，并从可退还金额扣罚金（封顶为押金）
- 账本：守住/没收次数与金额统计 + 历史明细

## 在你自己机器上打包成真机 App（Android APK）

> 本工程是在无法访问 Google 下载服务器的环境里写好的**完整可编译源码**。下面是你本机（有正常网络）把源码变成可安装 APK 的步骤。

### 1. 安装 Flutter 与 Android 环境

- 安装 Flutter SDK：<https://flutter.dev/docs/get-started> 或国内镜像 <https://flutter.cn>
- 安装 Android SDK / Android Studio，并运行 `flutter doctor` 按提示补齐（主要是 Android SDK + 平台工具 + 构建工具 + 同意协议）
- 用数据线连接安卓手机，打开「开发者选项 → USB 调试」

### 2. 恢复原生工程脚手架

Flutter 的原生 `android/`、`ios/` 目录（含 Gradle 包装器二进制）需由你的 Flutter 版本生成，运行：

```bash
cd pledge_alarm
flutter create --platforms android,ios .
```

这条命令**只补全原生目录**，不会改动 `lib/`、`pubspec.yaml`、`assets/` 里的代码。

### 3. 给 Android 清单加权限（让锁屏也能全屏响铃 + 精确闹钟）

打开 `android/app/src/main/AndroidManifest.xml`，把下面这份**完整内容**直接替换进去即可（已含所需权限与锁屏属性）：

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="押金闹钟"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:taskAffinity=""
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize"
            android:showWhenLocked="true"
            android:turnScreenOn="true">
            <meta-data
              android:name="io.flutter.embedding.android.NormalTheme"
              android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
</manifest>
```

> `SCHEDULE_EXACT_ALARM` 用于精确定时；`USE_FULL_SCREEN_INTENT` 用于锁屏直接弹出；`POST_NOTIFICATIONS` 用于 Android 13+ 显示通知。App 首次运行会请求精确闹钟权限。

### 4. 取依赖并构建

```bash
flutter pub get
# 连上手机后直接运行调试：
flutter run
# 或打出可安装的发布版 APK：
flutter build apk --release
# 安装到手机：
adb install build/app/outputs/flutter-apk/app-release.apk
```

APK 默认输出在 `build/app/outputs/flutter-apk/app-release.apk`，传到手机或用 `adb install` 安装即可。

## 工程结构

```
pledge_alarm/
├── pubspec.yaml              # 依赖与资源声明
├── assets/alarm.wav          # 循环报警音（本地合成）
└── lib/
    ├── main.dart             # 入口
    ├── models/session.dart   # 会话状态机 + 账本条目
    ├── services/
    │   ├── storage.dart      # SharedPreferences 本地持久化
    │   └── alarm_scheduler.dart # 定时 + 全屏通知 + 权限
    └── screens/
        ├── home_screen.dart      # 设置页
        ├── ringing_screen.dart   # 响铃 / 强制确认 / 没收
        └── ledger_screen.dart    # 账本统计
```

## 依赖

- `audioplayers` 循环播放报警音
- `flutter_local_notifications` 定时与全屏提醒
- `timezone` 精确时区定时
- `wakelock_plus` 响铃时屏幕常亮
- `shared_preferences` 本地设置与账本
- `intl` 时间格式化

## 说明 / 局限

- 定时响铃依赖系统精确闹钟；若被系统省电策略限制，可能略有偏差，建议在系统里把本 App 设为「不受电池优化限制」。
- iOS 上 `USE_FULL_SCREEN_INTENT` 等机制不同，重点验证 Android；如需 iOS 上架需额外处理通知权限与全屏呈现。
- 这是演示工程，所有金额均为虚拟数值。
