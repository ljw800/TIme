import 'package:flutter/material.dart';
import 'package:pledge_alarm/services/alarm_scheduler.dart';
import 'package:pledge_alarm/services/storage.dart';
import 'package:pledge_alarm/screens/home_screen.dart';
import 'package:pledge_alarm/screens/ringing_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AlarmScheduler.init();
  // 若被通知唤醒且已到点，直接进响铃页
  final pending = await Storage.getDueSession();
  runApp(MyApp(pending: pending));
}

class MyApp extends StatelessWidget {
  final Session? pending;
  const MyApp({super.key, this.pending});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '押金闹钟',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepOrange,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: pending != null
          ? RingingScreen(session: pending!)
          : const HomeScreen(),
    );
  }
}
