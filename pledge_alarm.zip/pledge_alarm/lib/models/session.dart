import 'dart:convert';

/// 一次闹钟会话的状态机：
/// armed    —— 已设定、等待到点（通知尚未触发或用户还没打开）
/// ringing  —— 正在响铃，等待用户确认起床 / 超时没收
/// success  —— 用户按时确认，押金原数（扣除贪睡罚金后）退还
/// forfeited—— 超时未确认，押金被没收
enum SessionStatus { armed, ringing, success, forfeited }

class Session {
  final int alarmId;
  final double pledge; // 本次押下的总金额
  final double penaltyPaid; // 已被贪睡扣掉的罚金
  final DateTime fireTime; // 闹钟应响时间
  final DateTime deadline; // 最后确认期限 = fireTime + 宽限分钟
  final String destination; // 没收去向：公益捐出 / 自己认栽
  final SessionStatus status;
  final int snoozeMinutes; // 每次贪睡续命时长
  final double snoozePenalty; // 每次贪睡罚金

  Session({
    required this.alarmId,
    required this.pledge,
    required this.penaltyPaid,
    required this.fireTime,
    required this.deadline,
    required this.destination,
    required this.status,
    required this.snoozeMinutes,
    required this.snoozePenalty,
  });

  /// 创建一次新的响铃会话（立即测试或到点触发时调用）
  factory Session.create({
    required int alarmId,
    required double pledge,
    required DateTime fireTime,
    required int graceMinutes,
    required String destination,
    required int snoozeMinutes,
    required double snoozePenalty,
  }) {
    return Session(
      alarmId: alarmId,
      pledge: pledge,
      penaltyPaid: 0,
      fireTime: fireTime,
      deadline: fireTime.add(Duration(minutes: graceMinutes)),
      destination: destination,
      status: SessionStatus.ringing,
      snoozeMinutes: snoozeMinutes,
      snoozePenalty: snoozePenalty,
    );
  }

  Session copyWith({
    double? penaltyPaid,
    DateTime? deadline,
    SessionStatus? status,
  }) {
    return Session(
      alarmId: alarmId,
      pledge: pledge,
      penaltyPaid: penaltyPaid ?? this.penaltyPaid,
      fireTime: fireTime,
      deadline: deadline ?? this.deadline,
      destination: destination,
      status: status ?? this.status,
      snoozeMinutes: snoozeMinutes,
      snoozePenalty: snoozePenalty,
    );
  }

  Map<String, dynamic> toJson() => {
        'alarmId': alarmId,
        'pledge': pledge,
        'penaltyPaid': penaltyPaid,
        'fireTime': fireTime.toIso8601String(),
        'deadline': deadline.toIso8601String(),
        'destination': destination,
        'status': status.name,
        'snoozeMinutes': snoozeMinutes,
        'snoozePenalty': snoozePenalty,
      };

  factory Session.fromJson(Map<String, dynamic> m) => Session(
        alarmId: m['alarmId'] as int,
        pledge: (m['pledge'] as num).toDouble(),
        penaltyPaid: (m['penaltyPaid'] as num).toDouble(),
        fireTime: DateTime.parse(m['fireTime'] as String),
        deadline: DateTime.parse(m['deadline'] as String),
        destination: m['destination'] as String,
        status: SessionStatus.values.byName(m['status'] as String),
        snoozeMinutes: (m['snoozeMinutes'] as num? ?? 5).toInt(),
        snoozePenalty: (m['snoozePenalty'] as num? ?? 5).toDouble(),
      );

  String toJsonString() => jsonEncode(toJson());
  factory Session.fromJsonString(String s) =>
      Session.fromJson(jsonDecode(s) as Map<String, dynamic>);
}

/// 账本条目（每一次结算的记录）
class LedgerEntry {
  final DateTime time;
  final bool success; // true=守住(退还) false=没收
  final double amount; // success: 退还金额；forfeited: 没收金额
  final String destination;

  LedgerEntry({
    required this.time,
    required this.success,
    required this.amount,
    required this.destination,
  });

  Map<String, dynamic> toJson() => {
        'time': time.toIso8601String(),
        'success': success,
        'amount': amount,
        'destination': destination,
      };

  factory LedgerEntry.fromJson(Map<String, dynamic> m) => LedgerEntry(
        time: DateTime.parse(m['time'] as String),
        success: m['success'] as bool,
        amount: (m['amount'] as num).toDouble(),
        destination: m['destination'] as String,
      );

  String toJsonString() => jsonEncode(toJson());
  factory LedgerEntry.fromJsonString(String s) =>
      LedgerEntry.fromJson(jsonDecode(s) as Map<String, dynamic>);
}
