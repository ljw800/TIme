import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pledge_alarm/models/session.dart';
import 'package:pledge_alarm/services/alarm_scheduler.dart';
import 'package:pledge_alarm/services/storage.dart';
import 'package:pledge_alarm/screens/ringing_screen.dart';
import 'package:pledge_alarm/screens/ledger_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double _pledge = 50;
  int _grace = 5;
  int _snoozeMin = 5;
  double _snoozePenalty = 5;
  String _destination = '公益捐出';
  TimeOfDay _alarmTime = const TimeOfDay(hour: 7, minute: 0);
  bool _alarmArmed = false;
  bool _busy = false;

  final List<String> _destinations = ['公益捐出', '自己认栽'];
  late final TextEditingController _pledgeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _pledgeController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await Storage.getPledge();
    final g = await Storage.getGraceMinutes();
    final sm = await Storage.getSnoozeMinutes();
    final sp = await Storage.getSnoozePenalty();
    final d = await Storage.getDestination();
    final (h, m) = await Storage.getAlarmTime();
    final active = await Storage.getActiveSession();
    final due = await Storage.getDueSession();
    if (mounted) {
      setState(() {
        _pledge = p;
        _grace = g;
        _snoozeMin = sm;
        _snoozePenalty = sp;
        _destination = d;
        _alarmTime = TimeOfDay(hour: h, minute: m);
        _alarmArmed = active != null;
      });
      _pledgeController.text = p.toInt().toString();
      // 如果闹钟已到点（或正在响铃），首帧后跳转响铃页
      if (due != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _goRinging(due);
        });
      }
    }
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
      context: context,
      initialTime: _alarmTime,
      helpText: '选择闹钟时间',
    );
    if (t != null) setState(() => _alarmTime = t);
  }

  void _goRinging(Session s) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => RingingScreen(session: s)),
    );
  }

  /// 计算“今天/明天”的响铃 DateTime
  DateTime _nextFire() {
    final now = DateTime.now();
    var fire = DateTime(
        now.year, now.month, now.day, _alarmTime.hour, _alarmTime.minute);
    if (fire.isBefore(now)) {
      fire = fire.add(const Duration(days: 1));
    }
    return fire;
  }

  Future<void> _armAlarm() async {
    setState(() => _busy = true);
    await Storage.setPledge(_pledge);
    await Storage.setGraceMinutes(_grace);
    await Storage.setSnoozeMinutes(_snoozeMin);
    await Storage.setSnoozePenalty(_snoozePenalty);
    await Storage.setDestination(_destination);
    await Storage.setAlarmTime(_alarmTime.hour, _alarmTime.minute);

    final fire = _nextFire();
    final session = Session.create(
      alarmId: AlarmScheduler.notificationId,
      pledge: _pledge,
      fireTime: fire,
      graceMinutes: _grace,
      destination: _destination,
      snoozeMinutes: _snoozeMin,
      snoozePenalty: _snoozePenalty,
    );
    await Storage.setActiveSession(session.copyWith(status: SessionStatus.armed));
    await AlarmScheduler.scheduleExact(fire);
    setState(() {
      _busy = false;
      _alarmArmed = true;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              '闹钟已设定：${DateFormat('MM-dd HH:mm').format(fire)} 响铃，押金 ¥${_pledge.toInt()} 进入待守'),
        ),
      );
    }
  }

  Future<void> _cancelAlarm() async {
    await AlarmScheduler.cancel();
    await Storage.clearActiveSession();
    setState(() => _alarmArmed = false);
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('已取消闹钟')));
    }
  }

  /// 立即测试：马上进入响铃页（不产生真实定时）
  Future<void> _testNow() async {
    await Storage.setPledge(_pledge);
    await Storage.setGraceMinutes(_grace);
    await Storage.setSnoozeMinutes(_snoozeMin);
    await Storage.setSnoozePenalty(_snoozePenalty);
    await Storage.setDestination(_destination);

    final session = Session.create(
      alarmId: AlarmScheduler.notificationId,
      pledge: _pledge,
      fireTime: DateTime.now(),
      graceMinutes: _grace,
      destination: _destination,
      snoozeMinutes: _snoozeMin,
      snoozePenalty: _snoozePenalty,
    );
    await Storage.setActiveSession(session);
    if (mounted) _goRinging(session);
  }

  @override
  Widget build(BuildContext context) {
    final fire = _nextFire();
    return Scaffold(
      appBar: AppBar(
        title: const Text('押金闹钟'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: '账本',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const LedgerScreen()),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _warningBanner(),
          const SizedBox(height: 12),
          _card(children: [
            const Text('虚拟押金', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                prefixText: '¥ ',
                border: OutlineInputBorder(),
                hintText: '例如 50',
              ),
              controller: _pledgeController,
              onChanged: (v) => _pledge = double.tryParse(v) ?? _pledge,
            ),
            const SizedBox(height: 6),
            const Text('仅本地演示数值，不接入真实支付，不会真的扣款。',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
          _card(children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('闹钟时间',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                TextButton.icon(
                  onPressed: _pickTime,
                  icon: const Icon(Icons.access_time),
                  label: Text(_alarmTime.format(context)),
                ),
              ],
            ),
            Text('下次响铃：${DateFormat('MM-dd HH:mm').format(fire)}',
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
          _card(children: [
            Text('确认宽限：$_grace 分钟',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            Slider(
              value: _grace.toDouble(),
              min: 1,
              max: 30,
              divisions: 29,
              label: '$_grace 分钟',
              onChanged: (v) => setState(() => _grace = v.toInt()),
            ),
            const Text('响铃后，必须在该时间内点“我起床了”才能守住押金。',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
          _card(children: [
            const Text('贪睡设置', style: TextStyle(fontWeight: FontWeight.bold)),
            Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('每次贪睡时长：$_snoozeMin 分钟'),
                    Slider(
                      value: _snoozeMin.toDouble(),
                      min: 1,
                      max: 30,
                      divisions: 29,
                      label: '$_snoozeMin 分',
                      onChanged: (v) => setState(() => _snoozeMin = v.toInt()),
                    ),
                  ],
                ),
              ),
            ]),
            Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('每次贪睡罚金：¥${_snoozePenalty.toInt()}'),
                    Slider(
                      value: _snoozePenalty,
                      min: 0,
                      max: 50,
                      divisions: 50,
                      label: '¥${_snoozePenalty.toInt()}',
                      onChanged: (v) => setState(() => _snoozePenalty = v),
                    ),
                  ],
                ),
              ),
            ]),
            const Text('贪睡能续命，但每次直接从可退还金额里扣罚金。',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
          _card(children: [
            const Text('赖床没收去向', style: TextStyle(fontWeight: FontWeight.bold)),
            DropdownButton<String>(
              value: _destination,
              isExpanded: true,
              items: _destinations
                  .map((d) => DropdownMenuItem(value: d, child: Text(d)))
                  .toList(),
              onChanged: (v) => setState(() => _destination = v!),
            ),
          ]),
          const SizedBox(height: 16),
          if (_alarmArmed)
            ElevatedButton.icon(
              onPressed: _busy ? null : _cancelAlarm,
              icon: const Icon(Icons.cancel),
              label: const Text('取消已设定的闹钟'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey[700]),
            )
          else
            ElevatedButton.icon(
              onPressed: _busy ? null : _armAlarm,
              icon: const Icon(Icons.alarm_add),
              label: const Text('保存并开启闹钟'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepOrange),
            ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _busy ? null : _testNow,
            icon: const Icon(Icons.play_arrow),
            label: const Text('立即测试（马上响铃）'),
          ),
        ],
      ),
    );
  }

  Widget _warningBanner() => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.amber.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.amber),
        ),
        child: const Row(
          children: [
            Icon(Icons.info_outline, color: Colors.amber),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                '本演示不接入真实支付，押金为虚拟数值；赖床“没收”只记入本地账本，钱流向是你自己或公益，绝不是开发者。',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ],
        ),
      );

  Widget _card({required List<Widget> children}) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: children,
          ),
        ),
      );
}
