import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pledge_alarm/services/storage.dart';
import 'package:pledge_alarm/models/session.dart';

class LedgerScreen extends StatefulWidget {
  const LedgerScreen({super.key});

  @override
  State<LedgerScreen> createState() => _LedgerScreenState();
}

class _LedgerScreenState extends State<LedgerScreen> {
  List<LedgerEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await Storage.getLedger();
    if (mounted) setState(() => _entries = list..sort((a, b) => b.time.compareTo(a.time)));
    if (mounted) setState(() => _loading = false);
  }

  (double saved, double forfeited, int savedN, int forfeitedN) _stats() {
    double saved = 0, forfeited = 0;
    int savedN = 0, forfeitedN = 0;
    for (final e in _entries) {
      if (e.success) {
        saved += e.amount;
        savedN++;
      } else {
        forfeited += e.amount;
        forfeitedN++;
      }
    }
    return (saved, forfeited, savedN, forfeitedN);
  }

  @override
  Widget build(BuildContext context) {
    final (saved, forfeited, savedN, forfeitedN) = _stats();
    return Scaffold(
      appBar: AppBar(
        title: const Text('押金账本'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: '清空账本',
            onPressed: () async {
              await Storage.clearLedger();
              _load();
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      _statCard('守住次数', savedN, Colors.green, '退还 ¥${saved.toInt()}'),
                      const SizedBox(width: 12),
                      _statCard('没收次数', forfeitedN, Colors.red, '捐出 ¥${forfeited.toInt()}'),
                    ],
                  ),
                ),
                const Divider(),
                Expanded(
                  child: _entries.isEmpty
                      ? const Center(
                          child: Text('还没有记录，去首页设定闹钟或立即测试吧。',
                              style: TextStyle(color: Colors.grey)),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.all(12),
                          itemCount: _entries.length,
                          separatorBuilder: (_, __) => const Divider(),
                          itemBuilder: (_, i) {
                            final e = _entries[i];
                            return ListTile(
                              leading: Icon(
                                e.success ? Icons.check_circle : Icons.money_off,
                                color: e.success ? Colors.green : Colors.red,
                              ),
                              title: Text(e.success
                                  ? '守住押金，退还 ¥${e.amount.toInt()}'
                                  : '赖床没收 ¥${e.amount.toInt()}'),
                              subtitle: Text(
                                  '${DateFormat('MM-dd HH:mm').format(e.time)} · ${e.destination}'),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }

  Widget _statCard(String title, int n, Color c, String sub) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                const SizedBox(height: 6),
                Text('$n', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: c)),
                Text(sub, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
        ),
      );
}
