import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:pledge_alarm/models/session.dart';
import 'package:pledge_alarm/services/storage.dart';
import 'package:pledge_alarm/screens/home_screen.dart';

class RingingScreen extends StatefulWidget {
  final Session session;
  const RingingScreen({super.key, required this.session});

  @override
  State<RingingScreen> createState() => _RingingScreenState();
}

class _RingingScreenState extends State<RingingScreen> {
  late DateTime _deadline;
  late double _penaltyPaid;
  final AudioPlayer _player = AudioPlayer();
  Timer? _ticker;
  bool _resolved = false;
  bool _resultSuccess = false;
  double _resultAmount = 0;

  @override
  void initState() {
    super.initState();
    _deadline = widget.session.deadline;
    _penaltyPaid = widget.session.penaltyPaid;
    _start();
  }

  Future<void> _start() async {
    // 屏幕常亮
    try {
      await WakelockPlus.enable();
    } catch (_) {}
    // 标记为 ringing，保持会话一致性
    await Storage.setActiveSession(
        widget.session.copyWith(status: SessionStatus.ringing));
    // 循环播放本地报警音
    try {
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.play(AssetSource('alarm.wav'));
    } catch (_) {}
    // 倒计时 + 超时没收检测
    _ticker = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (_resolved) return;
      if (DateTime.now().isAfter(_deadline)) {
        _forfeit();
      } else if (mounted) {
        setState(() {});
      }
    });
  }

  Future<void> _stopAudio() async {
    try {
      await _player.stop();
    } catch (_) {}
  }

  /// 用户确认起床：押金原数（扣掉贪睡罚金后）退还
  Future<void> _confirm() async {
    if (_resolved) return;
    _resolved = true;
    _ticker?.cancel();
    await _stopAudio();
    final refund = (widget.session.pledge - _penaltyPaid)
        .clamp(0, widget.session.pledge);
    await Storage.addLedger(LedgerEntry(
      time: DateTime.now(),
      success: true,
      amount: refund,
      destination: widget.session.destination,
    ));
    await Storage.setActiveSession(
        widget.session.copyWith(status: SessionStatus.success));
    try {
      await WakelockPlus.disable();
    } catch (_) {}
    setState(() {
      _resultSuccess = true;
      _resultAmount = refund;
    });
  }

  /// 超时未确认：押金被没收，记入账本
  Future<void> _forfeit() async {
    if (_resolved) return;
    _resolved = true;
    _ticker?.cancel();
    await _stopAudio();
    await Storage.addLedger(LedgerEntry(
      time: DateTime.now(),
      success: false,
      amount: widget.session.pledge,
      destination: widget.session.destination,
    ));
    await Storage.setActiveSession(
        widget.session.copyWith(status: SessionStatus.forfeited));
    try {
      await WakelockPlus.disable();
    } catch (_) {}
    setState(() {
      _resultSuccess = false;
      _resultAmount = widget.session.pledge;
    });
  }

  /// 贪睡：续命 N 分钟，但每次扣罚金
  Future<void> _snooze() async {
    if (_resolved) return;
    if (_penaltyPaid + widget.session.snoozePenalty > widget.session.pledge) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('罚金已达押金上限，无法再贪睡')),
        );
      }
      return;
    }
    setState(() {
      _penaltyPaid += widget.session.snoozePenalty;
      _deadline = _deadline.add(Duration(minutes: widget.session.snoozeMinutes));
    });
    await Storage.setActiveSession(widget.session.copyWith(
      penaltyPaid: _penaltyPaid,
      deadline: _deadline,
    ));
  }

  String _fmtRemaining() {
    final rem = _deadline.difference(DateTime.now());
    if (rem.isNegative) return '00:00';
    final s = rem.inSeconds;
    final mm = (s ~/ 60).toString().padLeft(2, '0');
    final ss = (s % 60).toString().padLeft(2, '0');
    return '$mm:$ss';
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _player.dispose();
    try {
      WakelockPlus.disable();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final atRisk = (widget.session.pledge - _penaltyPaid)
        .clamp(0, widget.session.pledge);
    return PopScope(
      canPop: _resolved,
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: _resolved
                  ? [Colors.grey.shade900, Colors.black]
                  : [Colors.red.shade900, Colors.black],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: _resolved ? _resultView() : _ringingView(atRisk),
            ),
          ),
        ),
      ),
    );
  }

  Widget _ringingView(double atRisk) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.alarm, size: 72, color: Colors.white),
          const SizedBox(height: 12),
          const Text('⏰ 该起床了！',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          Text(_fmtRemaining(),
              style: const TextStyle(
                  fontSize: 72,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'monospace')),
          const SizedBox(height: 8),
          Text('内确认起床，否则没收押金',
              style: TextStyle(fontSize: 16, color: Colors.red.shade200)),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black45,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text('当前待守押金：¥${atRisk.toInt()}',
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold)),
                if (_penaltyPaid > 0)
                  Text('已贪睡罚金：¥${_penaltyPaid.toInt()}',
                      style: const TextStyle(color: Colors.orange)),
                Text('没收去向：${widget.session.destination}',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            height: 60,
            child: ElevatedButton.icon(
              onPressed: _confirm,
              icon: const Icon(Icons.check_circle),
              label: const Text('我起床了 ✓ 守住押金',
                  style: TextStyle(fontSize: 20)),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green, foregroundColor: Colors.white),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton.icon(
              onPressed: _snooze,
              icon: const Icon(Icons.snooze),
              label: Text(
                  '贪睡 +${widget.session.snoozeMinutes}分钟（扣 ¥${widget.session.snoozePenalty.toInt()}）'),
              style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
            ),
          ),
        ],
      );

  Widget _resultView() => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _resultSuccess ? Icons.celebration : Icons.money_off,
            size: 80,
            color: _resultSuccess ? Colors.green : Colors.red,
          ),
          const SizedBox(height: 16),
          Text(
            _resultSuccess ? '押金已原数退还' : '押金已被没收',
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Text(
            _resultSuccess
                ? '退还金额 ¥${_resultAmount.toInt()}（${widget.session.destination}未受影响）'
                : '没收金额 ¥${_resultAmount.toInt()}，已记入「${widget.session.destination}」账本',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, color: Colors.grey),
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const HomeScreen()),
                (route) => false,
              ),
              child: const Text('返回首页', style: TextStyle(fontSize: 18)),
            ),
          ),
        ],
      );
}
