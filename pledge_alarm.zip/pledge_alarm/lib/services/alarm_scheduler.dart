import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzdata;

/// 封装本地通知：用于（1）定时到点响铃提醒 （2）锁屏全屏弹出响铃页。
/// 注意：Android 12+ 需要 SCHEDULE_EXACT_ALARM 权限，这里会在初始化时申请。
class AlarmScheduler {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static const String channelId = 'pledge_alarm_channel';
  static const int notificationId = 0;

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Shanghai'));
    } catch (_) {
      // 取不到就退回到设备本地时区
    }

    const androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (_) {
        // 用户点击通知打开 App 后，由 HomeScreen 检测进行中的会话并跳转响铃页
      },
    );

    // Android 12+ 精确闹钟权限
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestExactAlarmsPermission();
  }

  static const AndroidNotificationDetails _androidDetails =
      AndroidNotificationDetails(
    channelId,
    '押金闹钟',
    channelDescription: '赖床押金闹钟提醒',
    importance: Importance.max,
    priority: Priority.high,
    fullScreenIntent: true, // 锁屏也能直接全屏弹出
    playSound: false, // 声音由 audioplayers 循环播放，避免双声
    category: AndroidNotificationCategory.alarm,
    ongoing: true,
  );

  /// 设定一个精确闹钟：到点弹出全屏提醒并打开 App
  static Future<void> scheduleExact(DateTime fireAt) async {
    final tzFire = tz.TZDateTime.from(fireAt, tz.local);
    await _plugin.zonedSchedule(
      notificationId,
      '⏰ 该起床了！',
      '押金正处于待守状态，快去确认起床，否则将被没收。',
      tzFire,
      const NotificationDetails(android: _androidDetails),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  static Future<void> cancel() async {
    await _plugin.cancel(notificationId);
  }
}
