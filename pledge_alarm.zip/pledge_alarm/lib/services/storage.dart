import 'package:shared_preferences/shared_preferences.dart';
import 'package:pledge_alarm/models/session.dart';

/// 所有数据都存在本地 SharedPreferences 里。
/// 重要：押金是“虚拟数值”，本 App 不接入任何真实支付，也不会真的扣款。
class Storage {
  static const String _kPledge = 'pledge_amount';
  static const String _kGrace = 'grace_minutes';
  static const String _kSnoozeMin = 'snooze_minutes';
  static const String _kSnoozePenalty = 'snooze_penalty';
  static const String _kDestination = 'destination';
  static const String _kAlarmHour = 'alarm_hour';
  static const String _kAlarmMinute = 'alarm_minute';
  static const String _kActiveSession = 'active_session';
  static const String _kLedger = 'ledger';

  static SharedPreferences? _prefs;
  static Future<SharedPreferences> get prefs async =>
      _prefs ??= await SharedPreferences.getInstance();

  // ---------- 设置项 ----------

  static Future<double> getPledge() async =>
      (await prefs).getDouble(_kPledge) ?? 50.0;
  static Future<void> setPledge(double v) async =>
      (await prefs).setDouble(_kPledge, v);

  static Future<int> getGraceMinutes() async =>
      (await prefs).getInt(_kGrace) ?? 5;
  static Future<void> setGraceMinutes(int v) async =>
      (await prefs).setInt(_kGrace, v);

  static Future<int> getSnoozeMinutes() async =>
      (await prefs).getInt(_kSnoozeMin) ?? 5;
  static Future<void> setSnoozeMinutes(int v) async =>
      (await prefs).setInt(_kSnoozeMin, v);

  static Future<double> getSnoozePenalty() async =>
      (await prefs).getDouble(_kSnoozePenalty) ?? 5.0;
  static Future<void> setSnoozePenalty(double v) async =>
      (await prefs).setDouble(_kSnoozePenalty, v);

  static Future<String> getDestination() async =>
      (await prefs).getString(_kDestination) ?? '公益捐出';
  static Future<void> setDestination(String v) async =>
      (await prefs).setString(_kDestination, v);

  static Future<(int hour, int minute)> getAlarmTime() async {
    final p = await prefs;
    final h = p.getInt(_kAlarmHour) ?? 7;
    final m = p.getInt(_kAlarmMinute) ?? 0;
    return (h, m);
  }

  static Future<void> setAlarmTime(int hour, int minute) async {
    final p = await prefs;
    await p.setInt(_kAlarmHour, hour);
    await p.setInt(_kAlarmMinute, minute);
  }

  // ---------- 进行中的会话 ----------

  /// 仅在“已设定且尚未结算”时返回会话；已结算的返回 null。
  /// 用于首页判断是否显示「取消闹钟」。
  static Future<Session?> getActiveSession() async {
    final raw = (await prefs).getString(_kActiveSession);
    if (raw == null) return null;
    final s = Session.fromJsonString(raw);
    if (s.status == SessionStatus.success ||
        s.status == SessionStatus.forfeited) {
      return null;
    }
    return s;
  }

  /// 仅当“应当正在响铃”时返回会话：已处于 ringing，或已到点（现在 >= 应响时间）。
  /// 用于 App 启动时直接跳转到响铃页，避免还没到点就误触发。
  static Future<Session?> getDueSession() async {
    final s = await getActiveSession();
    if (s == null) return null;
    if (s.status == SessionStatus.ringing) return s;
    if (s.status == SessionStatus.armed &&
        DateTime.now().isAfter(s.fireTime)) {
      return s;
    }
    return null;
  }

  static Future<void> setActiveSession(Session s) async =>
      (await prefs).setString(_kActiveSession, s.toJsonString());

  static Future<void> clearActiveSession() async =>
      (await prefs).remove(_kActiveSession);

  // ---------- 账本 ----------

  static Future<List<LedgerEntry>> getLedger() async {
    final raw = (await prefs).getStringList(_kLedger) ?? [];
    return raw.map((e) => LedgerEntry.fromJsonString(e)).toList()
      ..sort((a, b) => b.time.compareTo(a.time));
  }

  static Future<void> addLedger(LedgerEntry e) async {
    final p = await prefs;
    final list = p.getStringList(_kLedger) ?? [];
    list.add(e.toJsonString());
    await p.setStringList(_kLedger, list);
  }

  static Future<void> clearLedger() async =>
      (await prefs).remove(_kLedger);
}
